
-- NUID:002922147
-- Hemanth Reddy Yaramala
-- Group 16
-- used gp16database
--**             create table sql              **--
CREATE TABLE  Transaction_type (
	TransactionType_ID int IDENTITY(1,1) NOT NULL,
	[Type] varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__Transact__66C96DFB9AEB53C5 PRIMARY KEY (TransactionType_ID)
);

CREATE TABLE  Transactions (
	Transaction_ID varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	TransactionType_ID int NULL,
	ReceiverAccount_no varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Transaction_date date NULL,
	Status varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__Transact__9A8D5625C730E3E7 PRIMARY KEY (Transaction_ID),
	CONSTRAINT FK__Transacti__Trans__367C1819 FOREIGN KEY (TransactionType_ID) REFERENCES  Transaction_type(TransactionType_ID)
);

CREATE TABLE  Policy_Coverage (
	Claim_ID int NOT NULL,
	Claim_date date NULL,
	Claim_Status varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Total_Amount int NULL,
	CONSTRAINT PK__Policy_C__811C4A4DF2F57583 PRIMARY KEY (Claim_ID)
);

CREATE TABLE  Bill (
	Bill_ID int IDENTITY(1,1) NOT NULL,
	[Date] date NULL,
	Amount_payable varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Billing_fname varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Billing_lname varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Billing_Address varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Claim_ID int NULL,
	Transaction_ID varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__Bill__CF6E7D4387C13D4C PRIMARY KEY (Bill_ID),
	CONSTRAINT FK__Bill__Claim_ID__3B40CD36 FOREIGN KEY (Claim_ID) REFERENCES  Policy_Coverage(Claim_ID),
	CONSTRAINT FK__Bill__Transactio__3C34F16F FOREIGN KEY (Transaction_ID) REFERENCES  Transactions(Transaction_ID)
);

CREATE TABLE  Services (
	Service_ID int IDENTITY(1,1) NOT NULL,
	Service_name varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Service_Type varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__Services__BD1A239CE5BDC934 PRIMARY KEY (Service_ID)
);

CREATE TABLE  Insurance_Agent (
	Agent_ID int NOT NULL,
	fname varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	lname varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	salary int NULL,
	CONSTRAINT PK__Insuranc__F4A9F96BA681A7CC PRIMARY KEY (Agent_ID)
);

CREATE TABLE  Insurance_Company (
	Company_ID int NOT NULL,
	Name varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Phone_number varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Address varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Claim_ID int NULL,
	Agent_ID int NULL,
	Service_ID int NULL,
	CONSTRAINT PK__Insuranc__5F5D19323172DBDA PRIMARY KEY (Company_ID),
	CONSTRAINT FK__Insurance__Agent__43D61337 FOREIGN KEY (Agent_ID) REFERENCES  Insurance_Agent(Agent_ID),
	CONSTRAINT FK__Insurance__Claim__42E1EEFE FOREIGN KEY (Claim_ID) REFERENCES  Policy_Coverage(Claim_ID),
	CONSTRAINT FK__Insurance__Servi__44CA3770 FOREIGN KEY (Service_ID) REFERENCES  Services(Service_ID)
);

CREATE TABLE  Insurance_Policy (
	Policy_ID int NOT NULL,
	Premium_Account int NULL,
	Issued_date date NULL,
	Expiration_date date NULL,
	Next_payment_date date NULL,
	Issued_location varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Company_ID int NULL,
	CONSTRAINT PK__Insuranc__4564AB414D460745 PRIMARY KEY (Policy_ID),
	CONSTRAINT FK__Insurance__Compa__47A6A41B FOREIGN KEY (Company_ID) REFERENCES  Insurance_Company(Company_ID)
);

CREATE TABLE  Driver (
	Driving_license varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	fname varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	lname varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Date_of_birth date NULL,
	CONSTRAINT PK__Driver__0EA7D565B2578A14 PRIMARY KEY (Driving_license)
);

CREATE TABLE  Vehicle (
	Registration_Number varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	Year_Of_Registration varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	State_of_Registration varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Date_of_issue varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Seating_Capacity varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Type] varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Brand varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Model varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Driving_license varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Policy_ID int NULL,
	CONSTRAINT PK__Vehicle__2F8BEE8E5DFF8A48 PRIMARY KEY (Registration_Number),
	CONSTRAINT FK__Vehicle__Driving__4C6B5938 FOREIGN KEY (Driving_license) REFERENCES  Driver(Driving_license),
	CONSTRAINT FK__Vehicle__Driving__5AB9788F FOREIGN KEY (Driving_license) REFERENCES  Driver(Driving_license),
	CONSTRAINT FK__Vehicle__Policy___4D5F7D71 FOREIGN KEY (Policy_ID) REFERENCES  Insurance_Policy(Policy_ID),
	CONSTRAINT FK__Vehicle__Policy___5BAD9CC8 FOREIGN KEY (Policy_ID) REFERENCES  Insurance_Policy(Policy_ID)
);

CREATE TABLE  Accident (
	Accident_ID int IDENTITY(1,1) NOT NULL,
	Location varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Date] date NULL,
	[Time] time NULL,
	Damage varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Registration_Number varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Driver_Pos varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__Accident__4EE1460D9329F996 PRIMARY KEY (Accident_ID),
	CONSTRAINT FK__Accident__Regist__503BEA1C FOREIGN KEY (Registration_Number) REFERENCES  Vehicle(Registration_Number)
);

CREATE TABLE  Customer (
	ID int IDENTITY(1,1) NOT NULL,
	SSN varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Fname varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Lname varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Gender varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Eamil varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Phone varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Registration_Number varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Claim_ID int NULL,
	CONSTRAINT PK__Customer__3214EC275484C025 PRIMARY KEY (ID),
	CONSTRAINT FK__Customer__Claim___540C7B00 FOREIGN KEY (Claim_ID) REFERENCES  Policy_Coverage(Claim_ID),
	CONSTRAINT FK__Customer__Regist__531856C7 FOREIGN KEY (Registration_Number) REFERENCES  Vehicle(Registration_Number)
);

CREATE TABLE  Address (
	Address_ID int IDENTITY(1,1) NOT NULL,
	City varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	State varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Zip varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__Address__03BDEBDA5C61C661 PRIMARY KEY (Address_ID)
);

CREATE TABLE  CustomerAddress (
	ID int NOT NULL,
	Address_ID int NOT NULL,
	CONSTRAINT PK__Customer__822F329AB5202829 PRIMARY KEY (ID,Address_ID),
	CONSTRAINT FK__CustomerA__Addre__59C55456 FOREIGN KEY (Address_ID) REFERENCES  Address(Address_ID),
	CONSTRAINT FK__CustomerAddr__ID__58D1301D FOREIGN KEY (ID) REFERENCES  Customer(ID)
);

Alter table Vehicle add VehicleCheck1 as(dbo.vehicle_check1(Date_of_issue))
ALTER Table Insurance_Policy ADD Policy_Status as (dbo.policy_status_function(Expiration_date));
ALTER table Policy_Coverage ADD No_of_Installments as (dbo.Installment_function(Total_Amount));


--**             create function sql              **--

CREATE FUNCTION CheckPositionOfDriver(@Aid int)
RETURNS int
AS
BEGIN
   DECLARE @Count int=0;
   SELECT @Count = COUNT(Accident_ID) 
          FROM Accident 
          WHERE Accident_ID = @Aid
          AND Driver_Pos = 'Drunk';
   RETURN @Count;
END;

CREATE FUNCTION Checkservice_type (@ServID INT)
RETURNS INT
BEGIN
   DECLARE @Count INT = 0;
   SELECT @Count= count(Service_ID)
      FROM dbo.Services
      WHERE Service_ID = @ServID AND Service_Type = 'Full'
   RETURN @Count;
END;

create FUNCTION Installment_function(
    @TAmount INT
)
returns INT
AS
BEGIN
     DECLARE @out int;
     RETURN
         CASE
            WHEN @TAmount BETWEEN 1 and  25000 THEN 1
            when @TAmount BETWEEN 25001 and  50000 THEN 2
            WHEN @TAmount BETWEEN 50000 and 100000 THEN 3
            ELSE 4
         END
END;

CREATE FUNCTION LookUpAgent (@CompID INT)
RETURNS INT
BEGIN
   DECLARE @AgentNum INT;
   SELECT @AgentNum = count(Agent_ID)
      FROM dbo.Insurance_Company
      WHERE Company_ID = @CompID AND @AgentNum IS NOT NULL;
   RETURN @AgentNUM;
END;

CREATE FUNCTION policy_status_function
(
    @EXPDate DATE
)
RETURNS VARCHAR
AS
BEGIN
    Declare @status int;
    SET @status=DATEDIFF(day,Getdate(),@EXPDate)
    RETURN
        CASE 
            WHEN @status > 0 THEN 'Y'
            ELSE 'N'
        END 
END;

create FUNCTION vehicle_check1(
    @bDate Date
)
returns VARCHAR
AS
BEGIN
     DECLARE @out int;
     set @out=DATEDIFF(year,@bDate,Getdate())
     RETURN
         CASE
            WHEN @out>=10 then 'Yes Required'
            else 'Not Required'
          
         END
END;

CREATE FUNCTION checkdamage (@RegNum Varchar(100))
RETURNS Varchar
BEGIN
   DECLARE @damage_check varchar(100);
   SELECT @damage_check = Damage
      FROM dbo.Accident
      WHERE Registration_Number = @RegNum AND dbo.Accident.Damage = 'ruined';
   RETURN @damage_check;
END;



--**             create data sql              **--
INSERT INTO Transaction_type ([Type]) VALUES
	 (N'creditcard'),
	 (N'debitcard'),
	 (N'EMI'),
	 (N'Cash'),
	 (N'check');
	
INSERT INTO Transactions (Transaction_ID,TransactionType_ID,ReceiverAccount_no,Transaction_date,Status) VALUES
	 (N'1',1,N'67876','2022-08-08',N'in progress'),
	 (N'10',4,N'67880','2022-09-04',N'Failed'),
	 (N'11',5,N'67885','2022-09-03',N'Success'),
	 (N'12',3,N'67886','2022-09-07',N'Success'),
	 (N'13',2,N'67888','2022-09-09',N'Success'),
	 (N'14',4,N'67899','2022-09-09',N'Success'),
	 (N'2',1,N'67877','2022-08-09',N'in progress'),
	 (N'3',3,N'67878','2022-09-01',N'success'),
	 (N'4',4,N'67879','2022-09-02',N'in progress'),
	 (N'5',5,N'67880','2022-09-03',N'Failed');
INSERT INTO Transactions (Transaction_ID,TransactionType_ID,ReceiverAccount_no,Transaction_date,Status) VALUES
	 (N'8',5,N'67880','2022-09-03',N'Failed');

INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(1, '2021-04-03', N'Claimed', 10452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(2, '2021-06-22', N'Claimed', 20444);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(3, '2022-01-01', N'In Approval', 230452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(4, '2022-05-23', N'Initiated', 2452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(5, '2022-02-22', N'Claimed', 100444);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(6, '2022-03-01', N'In Approval', 30452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(7, '2021-01-02', N'Claimed', 230452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(8, '2021-02-22', N'In Approval', 100444);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(9, '2021-03-01', N'Claimed', 30452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(10, '2021-04-03', N'Claimed', 10452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(11, '2021-06-22', N'Claimed', 20444);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(12, '2022-01-01', N'In Approval', 230452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(13, '2022-05-23', N'Initiated', 2452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(14, '2022-02-22', N'Claimed', 100444);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(15, '2022-03-01', N'In Approval', 30452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(16, '2021-01-02', N'Claimed', 230452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(17, '2021-02-22', N'In Approval', 100444);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(18, '2021-03-01', N'Claimed', 30452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(19, '2021-04-03', N'Claimed', 10452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(20, '2021-06-22', N'Claimed', 20444);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(21, '2022-01-01', N'In Approval', 230452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(22, '2022-05-23', N'Initiated', 2452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(23, '2022-02-22', N'Claimed', 100444);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(24, '2022-03-01', N'In Approval', 30452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(25, '2021-01-02', N'Claimed', 230452);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(26, '2021-02-22', N'In Approval', 100444);
INSERT INTO Policy_Coverage (Claim_ID, Claim_date, Claim_Status, Total_Amount) VALUES(27, '2021-03-01', N'Claimed', 30452);



INSERT INTO Bill ([Date],Amount_payable,Billing_fname,Billing_lname,Billing_Address,Claim_ID,Transaction_ID) VALUES
	 ('2021-01-01',N'12345',N'HR',N'Y',N'texas',1,N'1'),
	 ('2021-01-02',N'12333',N'Hem',N'Y',N'texas',3,N'2'),
	 ('2021-01-03',N'12343',N'Pink',N'S',N'texas',4,N'3'),
	 ('2021-02-03',N'12346',N'Zuyie',N'S',N'California',6,N'4'),
	 ('2021-02-05',N'12367',N'Chang',N'S',N'California',8,N'5'),
	 ('2021-02-05',N'12367',N'Chang',N'S',N'California',9,N'5'),
	 ('2021-02-05',N'12367',N'Chang',N'S',N'California',11,N'5'),
	 ('2021-02-06',N'12356',N'Akhil',N'S',N'MA',14,N'11'),
	 ('2021-03-04',N'12356',N'Akhil',N'S',N'AZ',18,N'11'),
	 ('2021-03-07',N'12388',N'nithin',N'S',N'AZ',25,N'11');
INSERT INTO Bill ([Date],Amount_payable,Billing_fname,Billing_lname,Billing_Address,Claim_ID,Transaction_ID) VALUES
	 ('2021-03-09',N'12399',N'AJ',N'y',N'AZ',26,N'12'),
	 ('2021-04-09',N'12340',N'HAR',N'y',N'AZ',27,N'13');

INSERT INTO Services (Service_name,Service_Type) VALUES
	 (N'PrivateCarInsurance',N'Full'),
	 (N'CommercialCarInsurance',N'Full'),
	 (N'TwoWheelerInsurance',N'Full'),
	 (N'Third-Party Liability ',N'Partial'),
	 (N'Collision Damage',N'Full'),
	 (N'ZeroDepreciationInsurance',N'Partial'),
	 (N'Comprehensive car insurance policy',N'Full'),
	 (N'Standalone own-damage car insurance policy',N'Full'),
	 (N'StandaloneThirdPartyCarInsurancePolicy',N'Full'),
	 (N'NoClaimBonusProtection',N'Partial');
INSERT INTO Services (Service_name,Service_Type) VALUES
	 (N'RoadsideAssistanceCover',N'Partial');

INSERT INTO Insurance_Agent (Agent_ID,fname,lname,salary) VALUES
	 (2048,N'Faustine',N'Wolfinger',6500),
	 (2412,N'Cherie',N'Hattersley',7500),
	 (3687,N'Kerry',N'Vivers',6500),
	 (4376,N'Lezley',N'Zavittieri',5500),
	 (4492,N'Myrtle',N'Mion',10000),
	 (5854,N'Felicio',N'Matusov',8000),
	 (6131,N'Dewey',N'Krzysztofiak',9000),
	 (7012,N'Cathie',N'Watterson',6000),
	 (7524,N'Enrique',N'Nulty',7500),
	 (8806,N'Salvatore',N'Bartzen',5800);

INSERT INTO Insurance_Company (Company_ID,Name,Phone_number,Address,Claim_ID,Agent_ID,Service_ID) VALUES
	 (2746,N'Robel Inc',N'(488) 3002515',N'973 Karstens Court',1,2048,1),
	 (2813,N'Hackett-Leannon',N'(434) 2732480',N'5518 Nobel Way',3,2412,4),
	 (3525,N'Bauch, Moen and Wolff',N'(768) 7080464',N'6069 Eliot Point',5,3687,5),
	 (4111,N'Adams-Ondricka',N'(886) 1335320',N'49 Lillian Lane',7,4492,5),
	 (4978,N'Greenholt, Lehner and Klocko',N'(172) 8294229',N'9 Westerfield Street',9,4376,6),
	 (5630,N'Emmerich-Walsh',N'(210) 5617556',N'4 Ruskin Plaza',11,5854,7),
	 (6248,N'Roberts-Langworth',N'(284) 3243318',N'6192 Dovetail Terrace',13,6131,3),
	 (7571,N'Runte, Hilll and Bayer',N'(854) 2869352',N'60176 Oxford Park',15,7524,6),
	 (7581,N'Ratke, Langosh and Bernhard',N'(553) 8846363',N'5120 Ludington Junction',18,7012,6),
	 (8421,N'Upton LLC',N'(227) 1252182',N'44305 Buena Vista Hill',20,8806,6);

INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(1010, 5696, '2019-05-20', '2025-01-22', '2021-09-26', N'6068 Dryden Place', 7571);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(1163, 4343, '2018-09-20', '2022-01-22', '2021-07-21', N'9 Steensland Alley', 7571);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(1229, 5048, '2020-09-13', '2021-08-20', '2021-09-16', N'3393 Brown Street', 3525);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(1349, 5334, '2007-04-20', '2025-03-24', '2004-04-22', N'85117 Melvin Trail', 2813);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(1442, 5481, '2020-10-15', '2021-08-24', '2001-09-22', N'35664 Carey Hill', 7571);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(1468, 3805, '2008-03-20', '2022-12-21', '2021-12-29', N'7755 Pepper Wood Point', 2813);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(1551, 3115, '2010-04-20', '2021-04-22', '2006-10-21', N'023 Butternut Terrace', 4978);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(1573, 3742, '2020-03-22', '2021-08-30', '2001-10-22', N'77247 Basil Road', 2746);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(1592, 4287, '2008-09-20', '2021-08-15', '2022-02-24', N'7782 Sunfield Hill', 8421);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(1776, 3144, '2004-02-20', '2021-10-27', '2021-06-28', N'855 Springview Junction', 5630);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(1958, 5004, '2020-01-25', '2022-03-27', '2022-01-24', N'42 Hintze Hill', 4978);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(2139, 4671, '2020-08-14', '2022-09-21', '2021-11-20', N'34 Carey Park', 2813);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(2276, 6356, '2020-06-16', '2021-09-18', '2021-09-13', N'19 Burrows Center', 7571);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(2363, 6574, '2020-03-17', '2023-09-29', '2021-12-24', N'75 Northridge Terrace', 8421);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(2415, 5183, '2020-01-28', '2022-01-15', '2005-04-21', N'2 Oak Park', 4978);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(2455, 6811, '2006-07-20', '2021-06-30', '2022-01-29', N'3 Judy Drive', 2813);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(2492, 3304, '2020-03-13', '2023-04-26', '2022-01-17', N'2742 Donald Court', 3525);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(2596, 6777, '2012-10-20', '2022-03-17', '2022-01-27', N'996 Algoma Pass', 2813);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(2708, 3372, '2006-08-20', '2024-07-31', '2001-07-22', N'22 Weeping Birch Lane', 6248);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(2757, 5490, '2011-10-20', '2022-02-25', '2009-09-21', N'8058 Oneill Crossing', 4978);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(2776, 5375, '2020-07-25', '2021-11-13', '2021-11-27', N'640 Fairview Place', 8421);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(3091, 4245, '2020-10-18', '2023-12-21', '2021-07-29', N'1353 Havey Park', 4978);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(3111, 3042, '2020-12-15', '2021-11-17', '2021-05-25', N'9 Clemons Lane', 3525);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(3142, 3152, '2020-06-24', '2022-03-20', '2021-06-18', N'1391 Schmedeman Way', 6248);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(3264, 4786, '2020-11-19', '2023-06-17', '2021-08-30', N'7 Redwing Trail', 2813);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(3300, 3909, '2020-04-16', '2023-06-28', '2001-02-22', N'682 South Place', 2813);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(3365, 3602, '2020-07-29', '2021-12-30', '2021-12-15', N'12182 Pawling Trail', 8421);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(3442, 6324, '2020-07-16', '2021-10-18', '2021-12-13', N'75562 Buhler Crossing', 3525);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(3565, 3572, '2020-01-20', '2028-03-21', '2021-07-13', N'34797 Manley Court', 3525);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(3635, 3374, '2020-03-20', '2021-07-25', '2008-10-21', N'46743 Northridge Pass', 6248);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(3675, 4702, '2020-11-24', '2021-11-23', '2021-12-26', N'3195 Meadow Ridge Street', 8421);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(3682, 5101, '2020-12-20', '2024-07-21', '2001-02-22', N'649 Vera Center', 2813);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(3861, 3105, '2020-09-23', '2022-03-30', '2021-06-23', N'5 Grover Parkway', 2746);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(3927, 4969, '2007-06-20', '2021-08-19', '2022-01-24', N'114 Pankratz Center', 7571);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(4078, 3095, '2020-08-26', '2022-01-17', '2010-10-21', N'5 Autumn Leaf Drive', 5630);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(4289, 4227, '2020-02-24', '2028-01-21', '2010-01-21', N'6 Pine View Pass', 3525);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(4411, 4560, '2020-04-18', '2022-01-18', '2021-06-25', N'2 Butterfield Hill', 5630);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(4511, 4128, '2020-04-15', '2021-08-27', '2021-12-28', N'25999 Chive Street', 8421);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(4514, 3197, '2020-07-14', '2026-11-22', '2001-02-22', N'4200 Dakota Plaza', 7571);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(4754, 5290, '2006-07-20', '2025-10-15', '2021-07-26', N'9084 Farwell Center', 6248);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(4768, 5259, '2003-12-20', '2022-02-19', '2021-12-21', N'5516 Tennessee Way', 5630);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(4881, 5614, '2020-08-23', '2023-02-20', '2009-10-21', N'6 Clemons Terrace', 2746);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(4900, 6296, '2020-08-29', '2021-04-26', '2021-07-29', N'4 Carpenter Avenue', 5630);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(4981, 5140, '2020-04-29', '2021-10-27', '2022-03-22', N'0549 Blaine Lane', 4978);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(5075, 5282, '2020-12-15', '2011-10-21', '2021-12-19', N'12 Caliangt Trail', 4978);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(5121, 6388, '2020-01-19', '2009-04-21', '2021-11-15', N'295 Susan Terrace', 7571);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(5123, 3896, '2002-09-20', '2021-08-20', '2021-08-18', N'98 Walton Alley', 6248);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(5145, 6695, '2002-03-20', '2021-07-15', '2021-05-18', N'78923 Barnett Pass', 5630);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(5193, 6432, '2020-06-22', '2001-10-22', '2004-03-22', N'24 Saint Paul Alley', 6248);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(5300, 4803, '2002-11-20', '2022-01-24', '2021-10-20', N'5724 Mosinee Road', 4978);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(5462, 4413, '2020-10-17', '2021-12-31', '2009-04-21', N'9 Riverside Lane', 2746);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(5565, 5481, '2002-12-20', '2004-08-22', '2021-09-26', N'627 Laurel Crossing', 6248);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(5767, 3827, '2003-11-20', '2021-10-25', '2007-07-21', N'6 Raven Plaza', 5630);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(5853, 3957, '2020-02-28', '2011-05-21', '2009-04-21', N'2 Muir Point', 2813);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(5899, 4873, '2020-09-18', '2003-03-22', '2005-06-21', N'2 Jenna Street', 4111);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(5921, 3425, '2020-06-29', '2021-11-15', '2005-01-21', N'75114 Lunder Way', 4978);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(5951, 4985, '2020-08-15', '2009-09-21', '2021-11-18', N'1 Vera Street', 2746);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(5966, 3418, '2004-12-20', '2021-06-17', '2021-05-29', N'03 Hoard Parkway', 7571);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(6044, 4328, '2020-05-25', '2006-07-21', '2009-11-21', N'25 Canary Drive', 3525);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(6078, 3105, '2020-03-25', '2003-09-22', '2009-08-21', N'4 Merchant Point', 4978);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(6081, 5983, '2020-12-13', '2022-02-17', '2021-05-19', N'4944 Orin Place', 3525);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(6159, 5645, '2012-02-20', '2021-11-24', '2021-06-28', N'6049 Mayer Parkway', 3525);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(6183, 3805, '2020-03-28', '2002-03-22', '2021-09-24', N'1005 Grim Street', 2746);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(6241, 6171, '2004-09-20', '2010-07-21', '2021-04-27', N'922 Atwood Pass', 6248);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(6300, 3997, '2020-01-18', '2008-09-21', '2011-11-21', N'51681 Lillian Court', 2813);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(6434, 3112, '2011-09-20', '2021-05-28', '2022-03-25', N'14034 Melby Place', 8421);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(6853, 3353, '2020-01-29', '2021-06-16', '2006-01-21', N'3 Dahle Point', 3525);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(7030, 3490, '2020-07-18', '2021-05-28', '2007-05-21', N'91 Calypso Plaza', 8421);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(7061, 4434, '2020-02-18', '2021-04-29', '2021-09-23', N'61 Tennyson Pass', 2746);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(7082, 6186, '2020-09-20', '2011-08-21', '2007-09-21', N'2604 Coleman Parkway', 7571);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(7091, 3664, '2020-09-15', '2006-09-21', '2022-03-14', N'8264 Goodland Street', 7571);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(7252, 3065, '2020-03-31', '2021-05-30', '2010-01-21', N'9562 Bay Park', 4111);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(7298, 4922, '2006-03-20', '2022-03-25', '2021-04-27', N'5580 Melby Plaza', 4978);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(7334, 6369, '2020-07-27', '2021-08-30', '2003-12-22', N'3 Jenifer Trail', 4978);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(7421, 6588, '2020-01-21', '2021-07-23', '2001-02-22', N'9460 Golf Course Center', 7571);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(7473, 3420, '2020-01-19', '2012-06-21', '2022-03-20', N'629 Shelley Pass', 4111);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(7690, 4861, '2020-07-24', '2021-07-23', '2021-04-22', N'497 Talisman Point', 6248);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(7815, 5736, '2020-06-15', '2022-02-28', '2003-10-22', N'03 Northfield Alley', 2813);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(7855, 6772, '2020-04-18', '2021-11-19', '2022-04-15', N'051 Arkansas Avenue', 4978);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(7920, 5027, '2020-02-13', '2005-04-21', '2021-08-29', N'45 Porter Center', 6248);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(8014, 5758, '2020-12-14', '2025-09-21', '2022-01-29', N'9195 Mandrake Center', 2746);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(8015, 4104, '2020-07-27', '2021-07-19', '2021-11-18', N'8 Eliot Hill', 4978);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(8035, 5515, '2005-05-20', '2024-07-22', '2006-09-21', N'908 Kingsford Crossing', 8421);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(8125, 4428, '2020-05-25', '2007-04-21', '2004-02-22', N'09 Oak Way', 5630);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(8147, 5811, '2020-05-19', '2024-10-23', '2021-06-22', N'936 Gina Center', 8421);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(8370, 3806, '2020-09-24', '2023-09-15', '2004-01-22', N'516 Trailsway Drive', 4111);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(8394, 3233, '2006-06-20', '2021-05-30', '2004-05-22', N'08 Badeau Avenue', 5630);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(8509, 3069, '2020-03-20', '2023-01-30', '2021-04-29', N'5 Sunbrook Circle', 8421);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(8564, 6629, '2020-01-21', '2021-05-14', '2012-03-21', N'3 North Place', 6248);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(8713, 5619, '2020-03-21', '2032-12-21', '2021-06-26', N'76006 Morrow Way', 6248);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(8734, 4387, '2002-05-20', '2022-01-30', '2022-02-14', N'4 Dahle Parkway', 4111);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(8747, 4166, '2006-07-20', '2024-10-19', '2021-12-24', N'28939 Sauthoff Court', 2813);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(8899, 3809, '2020-03-22', '2024-05-22', '2022-01-27', N'5 Vera Drive', 4111);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(8943, 5605, '2020-08-23', '2003-03-22', '2009-03-21', N'235 Mosinee Junction', 7571);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(8947, 4088, '2020-09-27', '2022-12-20', '2022-02-14', N'6774 Dovetail Point', 3525);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(9144, 3630, '2009-09-20', '2021-05-15', '2001-09-22', N'96108 Tony Drive', 3525);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(9200, 3839, '2020-02-16', '2021-06-24', '2021-08-18', N'57 Glacier Hill Trail', 2813);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(9220, 5751, '2020-04-27', '2021-07-27', '2010-11-21', N'1584 Lukken Park', 7571);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(9227, 6928, '2002-01-20', '2022-12-28', '2021-06-19', N'5802 Green Point', 8421);
INSERT INTO Insurance_Policy (Policy_ID, Premium_Account, Issued_date, Expiration_date, Next_payment_date, Issued_location, Company_ID) VALUES(9328, 5579, '2010-09-20', '2023-04-24', '2021-10-13', N'699 Maple Alley', 7571);


INSERT INTO Driver (Driving_license,fname,lname,Date_of_birth) VALUES
	 (N'1073',N'Lewie',N'Reddihough','1973-09-20'),
	 (N'1165',N'Pamella',N'Leivesley','1971-07-02'),
	 (N'1236',N'Drud',N'Mallinder','1978-02-20'),
	 (N'1260',N'Cathy',N'Osler','1995-03-01'),
	 (N'1274',N'Ursa',N'Wildgoose','1980-11-13'),
	 (N'1293',N'Jennifer',N'Feldheim','1980-11-29'),
	 (N'1417',N'Wenonah',N'Cove','1993-11-23'),
	 (N'1457',N'Dee',N'Sutterfield','1990-01-19'),
	 (N'1608',N'Heddi',N'Janosevic','1980-12-31'),
	 (N'1680',N'Myrtle',N'Mion','1988-02-09');
INSERT INTO Driver (Driving_license,fname,lname,Date_of_birth) VALUES
	 (N'1744',N'Chase',N'Sclanders','1976-10-21'),
	 (N'1853',N'Kellie',N'Lofting','1993-07-29'),
	 (N'1971',N'Corrianne',N'Chittem','1995-09-02'),
	 (N'2046',N'Cathie',N'Watterson','1985-09-19'),
	 (N'2141',N'Lorene',N'Greystoke','1980-07-09'),
	 (N'2301',N'Cirilo',N'Loache','1987-08-10'),
	 (N'2391',N'Hedvig',N'Sanpere','1990-10-08'),
	 (N'2434',N'Marcellina',N'Give','1981-05-06'),
	 (N'2515',N'Arnaldo',N'Rochelle','1986-09-09'),
	 (N'2719',N'Ellie',N'Kilfedder','1996-02-02');
INSERT INTO Driver (Driving_license,fname,lname,Date_of_birth) VALUES
	 (N'2750',N'Graig',N'Kilbee','1997-08-20'),
	 (N'2908',N'Enrique',N'Nulty','1987-07-24'),
	 (N'2947',N'Iggie',N'Kidney','1992-08-04'),
	 (N'2993',N'Jeana',N'Simunek','1974-11-02'),
	 (N'3207',N'Melloney',N'Gores','1996-07-27'),
	 (N'3446',N'Afton',N'Langlois','1973-05-30'),
	 (N'3471',N'Carter',N'Lightbourne','1996-09-13'),
	 (N'3609',N'Parke',N'Shalders','1989-07-31'),
	 (N'3612',N'Victor',N'Chess','1993-06-16'),
	 (N'3659',N'Faustine',N'Wolfinger','1987-04-07');
INSERT INTO Driver (Driving_license,fname,lname,Date_of_birth) VALUES
	 (N'3760',N'Vonni',N'Gounet','1997-08-01'),
	 (N'3781',N'Elonore',N'Yesson','1995-01-18'),
	 (N'4114',N'Lissie',N'Collard','1972-05-15'),
	 (N'4181',N'Stormy',N'Ettridge','1994-04-09'),
	 (N'4200',N'Granville',N'Govern','1974-08-07'),
	 (N'4465',N'Valentina',N'Dyton','1989-05-15'),
	 (N'4497',N'Floyd',N'Ingerson','1977-10-26'),
	 (N'4629',N'Kimberlyn',N'Grinov','1984-08-29'),
	 (N'4670',N'Lezley',N'Zavittieri','1977-06-11'),
	 (N'4722',N'Billie',N'Grendon','1983-09-20');
INSERT INTO Driver (Driving_license,fname,lname,Date_of_birth) VALUES
	 (N'4947',N'Yulma',N'Mickan','1990-12-12'),
	 (N'5077',N'Dougie',N'Gearing','1972-05-13'),
	 (N'5118',N'Crysta',N'Scowcraft','1981-01-11'),
	 (N'5132',N'Emera',N'Creasey','1991-05-03'),
	 (N'5134',N'Celina',N'Busher','1974-01-15'),
	 (N'5315',N'Vale',N'Cafe','1980-07-25'),
	 (N'5387',N'Neilla',N'Rounce','1996-06-23'),
	 (N'5576',N'Morry',N'Morilla','1973-01-23'),
	 (N'5586',N'Devondra',N'Hiscoke','1986-09-11'),
	 (N'5618',N'Zarla',N'Szach','1996-05-03');
INSERT INTO Driver (Driving_license,fname,lname,Date_of_birth) VALUES
	 (N'5643',N'Daron',N'Fernier','1970-01-10'),
	 (N'5713',N'Dewey',N'Krzysztofiak','1981-05-29'),
	 (N'5748',N'Dayna',N'Giroldo','1977-03-06'),
	 (N'5796',N'Nathanael',N'Blowne','1970-05-24'),
	 (N'5929',N'Nicholle',N'Wollard','1994-11-08'),
	 (N'6061',N'Melitta',N'Dobeson','1972-04-19'),
	 (N'6094',N'Virgil',N'Karp','1977-07-05'),
	 (N'6104',N'Pet',N'Duetschens','1994-09-17'),
	 (N'6266',N'Salvatore',N'Bartzen','1972-09-25'),
	 (N'6446',N'Cristiano',N'Gercken','1976-10-25');
INSERT INTO Driver (Driving_license,fname,lname,Date_of_birth) VALUES
	 (N'6510',N'Bald',N'Warner','1986-07-18'),
	 (N'6552',N'Any',N'Belch','1996-12-23'),
	 (N'6777',N'Sheridan',N'Blackader','1985-04-19'),
	 (N'6797',N'Dido',N'Edmondson','1997-04-27'),
	 (N'6815',N'Torrance',N'Langhorne','1986-08-15'),
	 (N'6923',N'Alina',N'Hovie','1984-11-25'),
	 (N'6962',N'Fowler',N'Rainsbury','1996-03-30'),
	 (N'7111',N'Joyan',N'Sor','1974-05-24'),
	 (N'7262',N'Masha',N'Klimmek','1993-09-10'),
	 (N'7489',N'Melodie',N'Baldree','1977-08-08');
INSERT INTO Driver (Driving_license,fname,lname,Date_of_birth) VALUES
	 (N'7526',N'Deina',N'Goodby','1995-02-11'),
	 (N'7595',N'Kerry',N'Vivers','1993-08-27'),
	 (N'7602',N'Cob',N'Robatham','1978-04-04'),
	 (N'7668',N'Giuditta',N'Le-Good','1975-11-26'),
	 (N'7939',N'Merrily',N'Bortoletti','1988-06-01'),
	 (N'8008',N'Meredeth',N'Szymanowicz','1976-05-02'),
	 (N'8145',N'Jon',N'Rumford','1979-10-11'),
	 (N'8166',N'Heda',N'De Marchi','1991-06-21'),
	 (N'8178',N'Cleveland',N'Whitehorne','1975-04-28'),
	 (N'8216',N'Ardelia',N'Dudgeon','1974-07-26');
INSERT INTO Driver (Driving_license,fname,lname,Date_of_birth) VALUES
	 (N'8251',N'Jone',N'Ruit','1974-07-18'),
	 (N'8279',N'Enrika',N'Raymont','1978-07-15'),
	 (N'8299',N'Helsa',N'Cuffe','1973-08-09'),
	 (N'8386',N'Mellicent',N'Tresise','1986-04-20'),
	 (N'8402',N'Revkah',N'Matyja','1989-09-13'),
	 (N'8585',N'Harri',N'Geater','1974-08-17'),
	 (N'8776',N'Keefe',N'Noel','1988-01-06'),
	 (N'8787',N'Papagena',N'Pettigree','1984-08-21'),
	 (N'8797',N'Josefa',N'Bollen','1974-08-08'),
	 (N'8893',N'Filbert',N'Poynton','1991-06-13');
INSERT INTO Driver (Driving_license,fname,lname,Date_of_birth) VALUES
	 (N'8933',N'Darrick',N'O''Grada','1971-10-02'),
	 (N'8983',N'Pernell',N'Bewick','1995-01-18'),
	 (N'9009',N'Danika',N'Bruin','1985-06-27'),
	 (N'9025',N'Neill',N'Byre','1997-08-16'),
	 (N'9128',N'Rhona',N'Evins','1981-10-18'),
	 (N'9421',N'Felicio',N'Matusov','1986-10-07'),
	 (N'9542',N'Cherie',N'Hattersley','1987-10-27'),
	 (N'9593',N'Nicolette',N'Glanton','1984-12-08'),
	 (N'9841',N'Inga',N'Beetham','1981-10-13'),
	 (N'9859',N'Leone',N'Grivori','1991-04-19');

INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0001A250091', N'2002', N'MA', N'2003-08-01', N'7', N'S80', N'Dodge', N'Dakota', N'1073', 1010);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0001K604957', N'2009', N'AL', N'2009-01-06', N'8', N'RX-7', N'Nissan', N'Murano', N'1165', 1163);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0002A556292', N'1992', N'AK', N'1992-02-03', N'4', N'Villager', N'Suzuki', N'Sidekick', N'1236', 1229);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0002U710469', N'2003', N'DE', N'2003-07-08', N'7', N'Maxima', N'Mercury', N'Sable', N'1260', 1349);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0003C670399', N'2004', N'CO', N'2004-08-04', N'5', N'Neon', N'BMW', N'S-Class', N'1274', 1442);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0003G574620', N'2009', N'ID', N'2009-08-06', N'5', N'Regal', N'Hyundai', N'Elantra', N'1293', 1468);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS00044606949', N'2005', N'IL', N'2005-03-02', N'4', N'S4', N'Volvo', N'S60', N'1417', 1551);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0004N792914', N'2010', N'VT', N'2010-04-02', N'4', N'Lancer Evolution', N'Dodge', N'Ram 2500', N'1457', 1573);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0005A391192', N'2006', N'WI', N'2006-03-01', N'9', N'Charger', N'Mazda', N'Mazda5', N'1608', 1592);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0005A733855', N'1997', N'WA', N'1997-01-01', N'6', N'Tundra', N'Nissan', N'Quest', N'1680', 1776);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0005D285004', N'1988', N'TX', N'1988-02-05', N'7', N'Neon', N'Ford', N'Tempo', N'1744', 1958);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0005D434794', N'1997', N'OR', N'1997-02-04', N'5', N'Jimmy', N'Dodge', N'Dakota Club', N'1853', 2139);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0005L650948', N'2011', N'OH', N'2011-09-02', N'7', N'Golf', N'Honda', N'Pilot', N'1971', 2276);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS00061045300', N'2011', N'MA', N'2011-03-02', N'6', N'Ram Van 3500', N'Ford', N'F250', N'2046', 2363);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0006G769981', N'2003', N'AL', N'2003-01-03', N'6', N'XC70', N'Mitsubishi', N'Lancer', N'2141', 2415);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0006N124455', N'2000', N'AK', N'2000-05-01', N'5', N'LeMans', N'Toyota', N'RAV4', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0007A119240', N'2006', N'DE', N'2006-07-02', N'6', N'Ram 2500', N'Nissan', N'Xterra', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0007C716852', N'1989', N'CO', N'1989-02-01', N'6', N'XC90', N'Suzuki', N'SJ', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0007K362760', N'1992', N'ID', N'1992-01-05', N'8', N'Landaulet', N'Plymouth', N'Colt', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0008A192462', N'2007', N'IL', N'2007-03-02', N'5', N'Sierra 3500', N'Ford', N'GT500', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0008L422839', N'2007', N'VT', N'2007-03-04', N'6', N'Spectra', N'Honda', N'Element', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0008N421897', N'2000', N'WI', N'2000-04-04', N'8', N'Ranger', N'Toyota', N'Avalon', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0008U711350', N'1994', N'WA', N'1994-09-08', N'6', N'Tracker', N'Ford', N'Club Wagon', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0009C787070', N'2012', N'TX', N'2012-04-03', N'6', N'RX', N'Chrysler', N'Santa Fe', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0009C914095', N'2010', N'OR', N'2010-03-02', N'8', N'Festiva', N'Bentley', N'Continental Super', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0009R227273', N'2005', N'OH', N'2005-03-04', N'4', N'ES', N'Honda', N'Pilot', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS0009R281879', N'1985', N'MA', N'1985-02-01', N'8', N'Express', N'Pontiac', N'Avalon', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000AB527556', N'2006', N'AL', N'2006-02-04', N'8', N'Swift', N'Mitsubishi', N'Endeavor', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000AE294008', N'1990', N'AK', N'1990-06-02', N'4', N'Ram 3500 Club', N'Maserati', N'Spyder', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000AE720659', N'2011', N'DE', N'2011-02-04', N'7', N'LX', N'Mercedes-Benz', N'S-Class', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000AK662331', N'1998', N'CO', N'1998-02-03', N'7', N'G6', N'Lexus', N'GS', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000AM692043', N'2011', N'ID', N'2011-05-04', N'7', N'Lucerne', N'Kia', N'Soul', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000AN738493', N'2009', N'IL', N'2009-09-09', N'7', N'Neon', N'Hyundai', N'Santa Fe', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000AT308925', N'1998', N'VT', N'1998-05-07', N'8', N'A5', N'Oldsmobile', N'Sidekick', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000AT969764', N'2007', N'WI', N'2007-06-04', N'4', N'del Sol', N'Nissan', N'Versa', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000AU889941', N'1995', N'WA', N'1995-05-04', N'5', N'IS', N'Ford', N'Ranger', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000B2232332', N'2002', N'TX', N'2002-05-05', N'8', N'3500 Club Coupe', N'Nissan', N'Maxima', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000BA099688', N'2012', N'OR', N'2022-04-05', N'9', N'Montero', N'Maybach', N'Landaulet', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000BA882622', N'2008', N'OH', N'2008-05-04', N'7', N'Camry Solara', N'Chevrolet', N'Avalanche', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000BE435334', N'1991', N'MA', N'1991-04-03', N'8', N'Town & Country', N'Mazda', N'RX-7', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000BG121771', N'2010', N'AL', N'2010-05-05', N'6', N'S10', N'Maserati', N'GranTurismo', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000BG179675', N'1999', N'AK', N'1999-08-01', N'6', N'Canyon', N'Buick', N'Regal', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000BG467300', N'2010', N'DE', N'2010-06-05', N'7', N'Prelude', N'Ford', N'F250', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000BJ271886', N'2010', N'CO', N'2010-05-05', N'8', N'Savana 1500', N'Mazda', N'RX-8', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000BM768569', N'2006', N'ID', N'2006-05-05', N'9', N'Paseo', N'Infiniti', N'G35', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000BM866631', N'1997', N'IL', N'1997-04-03', N'4', N'Sierra 1500', N'Pontiac', N'Firebird', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000BN524994', N'1993', N'VT', N'1993-05-04', N'6', N'RX-7', N'Plymouth', N'Laser', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000BS485809', N'2003', N'WI', N'2003-04-04', N'9', N'Paseo', N'Pontiac', N'Sunfire', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000BU948850', N'1999', N'WA', N'1999-05-04', N'8', N'M', N'Saab', N'Impulse', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000BZ290756', N'2011', N'TX', N'2011-04-01', N'7', N'FX', N'Subaru', N'Impreza WRX', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000CF198556', N'1999', N'OR', N'1999-07-04', N'4', N'ES', N'Lexus', N'RX', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000CG329305', N'2007', N'OH', N'2007-09-04', N'8', N'Passat', N'Buick', N'Terraza', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000CH168223', N'1993', N'MA', N'1993-04-04', N'5', N'Avalon', N'Oldsmobile', N'Bravada', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000CK729752', N'1990', N'AL', N'1990-04-03', N'5', N'Azera', N'Audi', N'S-Class', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000CS606946', N'1988', N'AK', N'1988-04-03', N'7', N'Mystique', N'Audi', N'5000S', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000CS770397', N'1995', N'DE', N'1995-03-05', N'5', N'Vega', N'Chevrolet', N'Monte Carlo', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000CT365211', N'1994', N'CO', N'1994-04-03', N'7', N'928', N'Lincoln', N'Continental', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000CW331385', N'1988', N'ID', N'1988-05-05', N'7', N'B-Series', N'Mercury', N'Tracer', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000D0180224', N'2007', N'IL', N'2007-04-01', N'8', N'Sportage', N'Toyota', N'Camry Solara', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000D0954254', N'2000', N'VT', N'2000-03-06', N'8', N'Corvette', N'Lexus', N'SC', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000D4392632', N'2009', N'WI', N'2009-05-02', N'8', N'Xtra', N'Cadillac', N'XLR', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000D6405716', N'2012', N'WA', N'2012-02-01', N'9', N'RL', N'Hyundai', N'Veloster', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000DA652551', N'1998', N'TX', N'1998-02-01', N'4', N'C70', N'Oldsmobile', N'Aurora', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000DC648838', N'1997', N'OR', N'1997-01-03', N'7', N'Windstar', N'Mercury', N'Sable', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000DD808731', N'1992', N'OH', N'1992-05-01', N'4', N'4Runner', N'Pontiac', N'Firefly', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000DE361337', N'2013', N'MA', N'2013-03-05', N'6', N'SC', N'Porsche', N'Boxster', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000DG379646', N'2008', N'AL', N'2008-05-03', N'7', N'Town Car', N'Infiniti', N'EX', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000DL183076', N'2009', N'AK', N'2009-03-07', N'8', N'E250', N'Infiniti', N'M', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000DM568610', N'1992', N'DE', N'1992-03-03', N'5', N'F250', N'Isuzu', N'Impulse', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000DN538186', N'1992', N'CO', N'1992-03-04', N'5', N'H3', N'Infiniti', N'Q', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000DN868121', N'2012', N'ID', N'2012-03-04', N'7', N'Passat', N'Jaguar', N'XK', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000E0151309', N'1970', N'IL', N'1970-03-02', N'6', N'SL-Class', N'Dodge', N'Charger', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000E0159708', N'1993', N'VT', N'1993-02-04', N'6', N'Outback', N'GMC', N'1500 Club Coupe', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000E1279112', N'2001', N'WI', N'2001-03-02', N'5', N'Reatta', N'Toyota', N'Celica', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000E2383352', N'2008', N'WA', N'2008-04-01', N'7', N'RX Hybrid', N'Cadillac', N'STS', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000EA758536', N'2009', N'TX', N'2009-05-01', N'4', N'Matrix', N'Jaguar', N'XK', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000ED942040', N'2001', N'OR', N'2001-03-05', N'6', N'S4', N'GMC', N'Savana 1500', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000EE260578', N'2009', N'OH', N'2009-06-05', N'9', N'V50', N'Bentley', N'Continental Flying Spur', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000EF799871', N'2012', N'MA', N'2012-03-04', N'7', N'Sequoia', N'Bentley', N'Continental', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000EF896050', N'2011', N'AL', N'2011-04-04', N'7', N'Sky', N'Lexus', N'GX', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000EG641626', N'1994', N'AK', N'1994-03-02', N'8', N'Suburban 2500', N'Dodge', N'Shadow', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000EH842482', N'2006', N'DE', N'2006-05-04', N'9', N'M3', N'Saab', N'Avalon', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000EM101273', N'2006', N'CO', N'2006-04-09', N'6', N'Mustang', N'Pontiac', N'Daewoo Kalos', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000EM897196', N'2005', N'ID', N'2005-05-04', N'4', N'Seville', N'Mitsubishi', N'Lancer', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000EN925570', N'2006', N'IL', N'2006-07-05', N'6', N'9-2X', N'Aston Martin', N'Vantage', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000EP000021', N'1991', N'VT', N'1991-02-04', N'9', N'Pilot', N'Lincoln', N'Town Car', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000EW720296', N'1994', N'WI', N'1994-01-03', N'6', N'Vibe', N'Mazda', N'B-Series Plus', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000F2387834', N'2002', N'WA', N'2002-03-05', N'7', N'Esteem', N'Nissan', N'Xterra', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000F5137462', N'2008', N'TX', N'2008-05-03', N'6', N'S4', N'Dodge', N'Caravan', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000F6217719', N'2009', N'OR', N'2009-03-06', N'8', N'Beetle', N'Bentley', N'Brooklands', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000FA554702', N'2010', N'OH', N'2010-02-01', N'4', N'MX-5', N'Land Rover', N'Range Rover Sport', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000FB434859', N'2009', N'VT', N'2009-01-01', N'9', N'S10', N'Nissan', N'Frontier', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000FC740876', N'2004', N'WI', N'2004-02-06', N'6', N'Pathfinder', N'Chevrolet', N'S10', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000FM006729', N'1991', N'WA', N'1991-03-02', N'9', N'Sierra 1500', N'Chevrolet', N'Caprice', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000FM934193', N'1999', N'TX', N'1999-05-03', N'7', N'Savana 1500', N'Kia', N'Sephia', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000FN906176', N'1994', N'OR', N'1994-03-07', N'6', N'Tacoma', N'Audi', N'Quattro', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000FS409852', N'1999', N'OH', N'1999-03-02', N'8', N'Touareg', N'Chevrolet', N'Club Wagon', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000FU365753', N'2000', N'OR', N'2000-03-02', N'4', N'Grand Prix', N'BMW', N'3 Series', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000FU478082', N'2006', N'OR', N'2006-04-09', N'8', N'Verona', N'Kia', N'Rio', NULL, NULL);
INSERT INTO Vehicle (Registration_Number, Year_Of_Registration, State_of_Registration, Date_of_issue, Seating_Capacity, [Type], Brand, Model, Driving_license, Policy_ID) VALUES(N'MDS000GB555700', N'1993', N'OR', N'1993-02-03', N'5', N'IS', N'Isuzu', N'Space', NULL, NULL);
	
INSERT INTO Accident (Location,[Date],[Time],Damage,Registration_Number,Driver_Pos) VALUES
	 (N'47465 Rutledge Center','2021-08-02','23:52:00.0000000',N'light',N'MDS000E2383352',N'Normal'),
	 (N'743 Jackson Hill','2021-06-09','05:03:00.0000000',N'ruined',N'MDS000B2232332',N'Normal'),
	 (N'21 Texas Way','2022-06-05','15:01:00.0000000',N'medium',N'MDS000DA652551',N'Unhealthy'),
	 (N'75 Union Way','2020-05-06','23:27:00.0000000',N'severe',N'MDS000CH168223',N'Drunk'),
	 (N'90 Golf View Hill','2020-03-09','04:08:00.0000000',N'medium',N'MDS000BU948850',N'Normal'),
	 (N'4109 Scofield Pass','2021-11-05','20:12:00.0000000',N'severe',N'MDS0005L650948',N'Normal'),
	 (N'61766 Gale Parkway','2022-03-03','07:01:00.0000000',N'light',N'MDS0005A733855',N'Normal'),
	 (N'47484 Dorton Park','2021-07-05','17:31:00.0000000',N'light',N'MDS000BG179675',N'Normal'),
	 (N'76 Onsgard Alley','2020-11-02','15:44:00.0000000',N'severe',N'MDS000ED942040',N'Normal'),
	 (N'0363 Arkansas Place','2021-07-06','13:04:00.0000000',N'light',N'MDS000CS606946',N'Normal');
INSERT INTO Accident (Location,[Date],[Time],Damage,Registration_Number,Driver_Pos) VALUES
	 (N'1 Autumn Leaf Place','2020-02-02','23:55:00.0000000',N'light',N'MDS00044606949',N'Normal'),
	 (N'299 Continental Junction','2022-05-08','19:26:00.0000000',N'severe',N'MDS000GB555700',N'Normal'),
	 (N'28741 Lindbergh Plaza','2021-10-02','09:25:00.0000000',N'light',N'MDS000BA099688',N'Normal'),
	 (N'237 Maple Wood Terrace','2022-03-06','17:40:00.0000000',N'light',N'MDS000F5137462',N'Normal'),
	 (N'20 Dawn Junction','2022-01-08','06:15:00.0000000',N'severe',N'MDS000DM568610',N'Normal'),
	 (N'655 Stang Plaza','2021-06-11','07:11:00.0000000',N'light',N'MDS000EW720296',N'Normal'),
	 (N'32 Moland Point','2021-06-11','21:13:00.0000000',N'severe',N'MDS000EN925570',N'Drunk'),
	 (N'6 Dixon Place','2021-06-05','05:10:00.0000000',N'severe',N'MDS000EE260578',N'Normal'),
	 (N'09585 Old Shore Parkway','2022-03-05','12:43:00.0000000',N'medium',N'MDS0007A119240',N'Normal'),
	 (N'339 Nancy Avenue','2022-06-08','12:19:00.0000000',N'medium',N'MDS000DL183076',N'drunk');
INSERT INTO Accident (Location,[Date],[Time],Damage,Registration_Number,Driver_Pos) VALUES
	 (N'6892 Talmadge Road','2021-12-10','10:14:00.0000000',N'severe',N'MDS0007K362760',N'Normal'),
	 (N'283 Dapin Place','2020-07-06','23:00:00.0000000',N'light',N'MDS000AN738493',N'Normal'),
	 (N'5 Myrtle Plaza','2021-05-03','19:35:00.0000000',N'ruined',N'MDS000FB434859',N'Normal'),
	 (N'5 Maywood Pass','2022-01-10','21:57:00.0000000',N'ruined',N'MDS0009C787070',N'unhealhty'),
	 (N'25 Gale Street','2021-09-07','00:55:00.0000000',N'ruined',N'MDS000EP000021',N'Normal'),
	 (N'69 Hoepker Center','2021-07-05','20:24:00.0000000',N'severe',N'MDS000BN524994',N'Normal'),
	 (N'6714 Artisan Terrace','2022-01-07','08:40:00.0000000',N'medium',N'MDS000D4392632',N'Normal'),
	 (N'2 Mitchell Way','2022-01-12','07:29:00.0000000',N'light',N'MDS000EH842482',N'Unhealthy'),
	 (N'368 Dexter Drive','2021-03-08','08:52:00.0000000',N'light',N'MDS000CK729752',N'Normal'),
	 (N'0602 Schmedeman Point','2020-06-06','01:13:00.0000000',N'light',N'MDS000DD808731',N'Normal');
INSERT INTO Accident (Location,[Date],[Time],Damage,Registration_Number,Driver_Pos) VALUES
	 (N'42278 Brickson Park Lane','2020-03-06','09:15:00.0000000',N'light',N'MDS000DN538186',N'Normal'),
	 (N'14 Del Mar Circle','2021-06-09','13:29:00.0000000',N'ruined',N'MDS0001K604957',N'Normal'),
	 (N'32 Hermina Park','2020-03-01','17:23:00.0000000',N'medium',N'MDS000EF896050',N'Normal'),
	 (N'96 Holmberg Junction','2021-12-07','15:12:00.0000000',N'severe',N'MDS000DN868121',N'drunk'),
	 (N'425 Doe Crossing Court','2020-10-02','00:43:00.0000000',N'medium',N'MDS000FC740876',N'unhealthy'),
	 (N'804 Truax Way','2022-04-03','15:59:00.0000000',N'severe',N'MDS000E0151309',N'Normal'),
	 (N'34639 Maple Wood Pass','2021-11-01','20:35:00.0000000',N'light',N'MDS000BZ290756',N'Normal'),
	 (N'258 Lien Center','2020-09-04','21:04:00.0000000',N'light',N'MDS0008N421897',N'drunk'),
	 (N'8853 Vidon Alley','2020-08-11','03:48:00.0000000',N'severe',N'MDS000EA758536',N'Normal'),
	 (N'1599 Annamark Plaza','2020-06-08','01:50:00.0000000',N'light',N'MDS0005A391192',N'Normal');
INSERT INTO Accident (Location,[Date],[Time],Damage,Registration_Number,Driver_Pos) VALUES
	 (N'5 Thompson Terrace','2021-07-09','06:13:00.0000000',N'light',N'MDS000AE294008',N'Normal'),
	 (N'80 Fuller Place','2020-12-12','13:09:00.0000000',N'severe',N'MDS000AE720659',N'Normal'),
	 (N'16411 Aberg Parkway','2020-10-04','15:45:00.0000000',N'light',N'MDS000AB527556',N'Normal'),
	 (N'90 Veith Pass','2021-01-05','21:35:00.0000000',N'light',N'MDS000BM866631',N'unhealthy'),
	 (N'8263 Hovde Place','2021-10-01','11:16:00.0000000',N'severe',N'MDS0009C914095',N'drunk'),
	 (N'3 Mayfield Avenue','2022-03-06','09:40:00.0000000',N'light',N'MDS0009R281879',N'drunk'),
	 (N'0 5th Point','2022-01-04','11:26:00.0000000',N'severe',N'MDS0006G769981',N'unhealthy'),
	 (N'1164 Goodland Alley','2020-10-06','21:29:00.0000000',N'severe',N'MDS0005D434794',N'drunk'),
	 (N'1819 Paget Alley','2022-02-12','01:38:00.0000000',N'medium',N'MDS000BG467300',N'Normal'),
	 (N'7348 Sutherland Point','2022-03-02','01:58:00.0000000',N'medium',N'MDS000CW331385',N'Normal');
INSERT INTO Accident (Location,[Date],[Time],Damage,Registration_Number,Driver_Pos) VALUES
	 (N'88 Sycamore Circle','2022-04-11','16:29:00.0000000',N'severe',N'MDS000AK662331',N'Normal'),
	 (N'77 Washington Street','2020-03-06','11:02:00.0000000',N'light',N'MDS000EM897196',N'Normal'),
	 (N'9674 Duke Point','2021-11-03','20:29:00.0000000',N'ruined',N'MDS000EG641626',N'Normal'),
	 (N'47994 Heffernan Trail','2020-08-07','23:39:00.0000000',N'ruined',N'MDS000FM934193',N'Normal'),
	 (N'44 Susan Circle','2022-03-07','22:23:00.0000000',N'ruined',N'MDS000F2387834',N'Normal'),
	 (N'52242 Dakota Way','2021-10-09','06:23:00.0000000',N'severe',N'MDS000AU889941',N'Normal'),
	 (N'7 Parkside Parkway','2022-02-11','07:48:00.0000000',N'medium',N'MDS000EF799871',N'drunk'),
	 (N'58 Welch Circle','2022-03-10','09:36:00.0000000',N'light',N'MDS0004N792914',N'unhealthy'),
	 (N'8 Almo Road','2022-04-05','20:13:00.0000000',N'light',N'MDS0002U710469',N'unhealth'),
	 (N'6893 Welch Drive','2022-03-11','09:59:00.0000000',N'light',N'MDS000CT365211',N'Normal');
INSERT INTO Accident (Location,[Date],[Time],Damage,Registration_Number,Driver_Pos) VALUES
	 (N'476 Derek Terrace','2020-07-12','06:05:00.0000000',N'light',N'MDS0005D285004',N'Normal'),
	 (N'03 Scott Hill','2021-01-08','12:34:00.0000000',N'ruined',N'MDS000FU365753',N'Normal'),
	 (N'1 Trailsway Parkway','2020-10-06','07:41:00.0000000',N'medium',N'MDS000DC648838',N'Normal'),
	 (N'35848 Aberg Street','2022-07-08','14:03:00.0000000',N'severe',N'MDS0003C670399',N'Normal'),
	 (N'9 Dunning Avenue','2020-11-10','12:51:00.0000000',N'medium',N'MDS000D0180224',N'Normal'),
	 (N'084 Division Way','2021-11-05','08:10:00.0000000',N'severe',N'MDS000FA554702',N'Normal'),
	 (N'415 Main Avenue','2022-03-01','17:50:00.0000000',N'light',N'MDS000CG329305',N'Normal'),
	 (N'16 Butternut Way','2022-02-06','17:13:00.0000000',N'light',N'MDS000FS409852',N'Normal'),
	 (N'563 Corben Circle','2021-04-01','13:23:00.0000000',N'severe',N'MDS0003G574620',N'Normal'),
	 (N'7 Milwaukee Trail','2021-03-04','14:47:00.0000000',N'light',N'MDS000FN906176',N'drunk');
INSERT INTO Accident (Location,[Date],[Time],Damage,Registration_Number,Driver_Pos) VALUES
	 (N'58227 Homewood Terrace','2020-02-10','20:42:00.0000000',N'light',N'MDS000BS485809',N'drunk'),
	 (N'29629 Lillian Drive','2021-04-12','20:28:00.0000000',N'severe',N'MDS000AT969764',N'unhealthy'),
	 (N'72607 Farragut Crossing','2020-06-04','17:35:00.0000000',N'light',N'MDS000FU478082',N'Normal'),
	 (N'81680 Corscot Point','2020-05-10','11:19:00.0000000',N'light',N'MDS0008U711350',N'Normal'),
	 (N'16 Grover Hill','2020-04-12','10:48:00.0000000',N'severe',N'MDS000D6405716',N'Normal'),
	 (N'64 Schlimgen Terrace','2020-05-04','05:55:00.0000000',N'light',N'MDS00061045300',N'Normal'),
	 (N'6662 Grasskamp Center','2020-11-03','08:31:00.0000000',N'severe',N'MDS000EM101273',N'Normal'),
	 (N'5272 Debra Pass','2021-12-04','16:24:00.0000000',N'severe',N'MDS000CS770397',N'Normal'),
	 (N'5 Bowman Plaza','2021-09-04','00:31:00.0000000',N'medium',N'MDS000E1279112',N'Normal'),
	 (N'5 Clove Point','2021-03-11','11:19:00.0000000',N'medium',N'MDS000F6217719',N'Normal');
INSERT INTO Accident (Location,[Date],[Time],Damage,Registration_Number,Driver_Pos) VALUES
	 (N'7 Sheridan Circle','2020-06-06','20:18:00.0000000',N'severe',N'MDS0006N124455',N'Normal'),
	 (N'44056 Quincy Junction','2020-10-07','21:11:00.0000000',N'light',N'MDS000DG379646',N'Normal'),
	 (N'05 Ridgeway Hill','2020-09-11','13:27:00.0000000',N'ruined',N'MDS0008L422839',N'Normal'),
	 (N'07 3rd Drive','2020-06-09','03:44:00.0000000',N'ruined',N'MDS000BA882622',N'drunk'),
	 (N'0444 Hagan Pass','2022-02-08','09:35:00.0000000',N'ruined',N'MDS000BJ271886',N'unhealthy'),
	 (N'39352 Almo Court','2021-06-04','01:30:00.0000000',N'severe',N'MDS0001A250091',N'unhealthy'),
	 (N'1 Declaration Court','2020-01-10','19:04:00.0000000',N'medium',N'MDS000AM692043',N'Normal'),
	 (N'79 Butterfield Junction','2022-05-12','04:27:00.0000000',N'light',N'MDS000E0159708',N'Normal'),
	 (N'8912 Schurz Place','2020-05-03','18:08:00.0000000',N'light',N'MDS000DE361337',N'Normal'),
	 (N'85492 Sheridan Parkway','2021-10-10','23:07:00.0000000',N'light',N'MDS0007C716852',N'Normal');
INSERT INTO Accident (Location,[Date],[Time],Damage,Registration_Number,Driver_Pos) VALUES
	 (N'0144 Petterle Street','2021-03-02','16:29:00.0000000',N'light',N'MDS000BE435334',N'Normal'),
	 (N'05342 Sundown Center','2020-06-03','18:05:00.0000000',N'medium',N'MDS000AT308925',N'Normal'),
	 (N'4 Crownhardt Pass','2020-10-02','21:05:00.0000000',N'light',N'MDS000BG121771',N'drunk'),
	 (N'89 Armistice Point','2022-03-03','09:57:00.0000000',N'light',N'MDS0008A192462',N'Normal'),
	 (N'82955 Steensland Trail','2021-08-10','04:57:00.0000000',N'medium',N'MDS0002A556292',N'Normal'),
	 (N'64 Holy Cross Place','2021-10-03','21:50:00.0000000',N'medium',N'MDS0009R227273',N'Normal'),
	 (N'95 Raven Point','2021-03-01','07:32:00.0000000',N'medium',N'MDS000FM006729',N'drunk'),
	 (N'3172 Moulton Alley','2021-10-11','20:39:00.0000000',N'light',N'MDS000CF198556',N'Normal'),
	 (N'168 Lakeland Circle','2020-01-12','21:41:00.0000000',N'light',N'MDS000D0954254',N'Normal'),
	 (N'43 Main Avenue','2021-02-07','06:20:00.0000000',N'light',N'MDS000BM768569',N'Normal');
INSERT INTO Accident (Location,[Date],[Time],Damage,Registration_Number,Driver_Pos) VALUES
	 (N'16 Grover Hill','2021-09-04','10:48:00.0000000',N'severe',N'MDS000FA554702',N'Normal'),
	 (N'16 Grover Hill','2021-09-04','10:48:00.0000000',N'severe',N'MDS000CG329305',N'Normal'),
	 (N'16 Grover Hill','2021-09-04','10:48:00.0000000',N'severe',N'MDS000FS409852',N'Normal'),
	 (N'05 Ridgeway Hill','2020-09-11','13:27:00.0000000',N'ruined',N'MDS000E1279112',N'Normal'),
	 (N'05 Ridgeway Hill','2020-09-11','13:27:00.0000000',N'severe',N'MDS000F6217719',N'Normal'),
	 (N'05 Ridgeway Hill','2020-09-11','13:27:00.0000000',N'medium',N'MDS0006N124455',N'Normal'),
	 (N'05 Ridgeway Hill','2020-09-11','13:27:00.0000000',N'light',N'MDS000DG379646',N'Normal'),
	 (N'05342 Sundown Center','2021-03-11','18:08:00.0000000',N'light',N'MDS000CF198556',N'Normal'),
	 (N'05342 Sundown Center','2021-03-11','18:08:00.0000000',N'light',N'MDS0002A556292',N'Normal'),
	 (N'05342 Sundown Center','2021-03-11','18:08:00.0000000',N'light',N'MDS0009R227273',N'Normal');
INSERT INTO Accident (Location,[Date],[Time],Damage,Registration_Number,Driver_Pos) VALUES
	 (N'05342 Sundown Center','2021-03-11','18:08:00.0000000',N'ruined',N'MDS0008L422839',N'Normal');

INSERT INTO Customer (SSN,Fname,Lname,Gender,Eamil,Phone,Registration_Number,Claim_ID) VALUES
	 (N'444-54-3492',N'Brander',N'Saulter',N'Male',N'bsaulter0@parallels.com',N'(904) 3953095',N'MDS000E2383352',1),
	 (N'476-89-5232',N'Judy',N'Hugnin',N'Female',N'jhugnin1@goo.ne.jp',N'(941) 2128871',N'MDS000B2232332',2),
	 (N'635-25-6460',N'Drucy',N'Barribal',N'Female',N'dbarribal2@irs.gov',N'(202) 6071173',N'MDS000DA652551',4),
	 (N'861-90-4383',N'Dido',N'Edmondson',N'Female',N'dedmondson3@usgs.gov',N'(202) 6155221',N'MDS000CH168223',5),
	 (N'661-51-7355',N'Moll',N'Blasius',N'Female',N'mblasius4@zdnet.com',N'(334) 9119241',N'MDS000BU948850',6),
	 (N'851-39-3600',N'Hermina',N'Toulch',N'Female',N'htoulch5@privacy.gov.au',N'(469) 6531083',N'MDS0005L650948',7),
	 (N'138-51-3282',N'Victor',N'Chess',N'Male',N'vchess6@cisco.com',N'(404) 6876322',N'MDS0005A733855',8),
	 (N'599-17-2021',N'Constantia',N'Senecaux',N'Female',N'csenecaux7@rambler.ru',N'(803) 6169917',N'MDS000BG179675',9),
	 (N'392-75-7855',N'Demeter',N'Dyment',N'Female',N'ddyment8@whitehouse.gov',N'(202) 6255276',N'MDS000ED942040',10),
	 (N'888-67-3889',N'Ignace',N'Bealton',N'Male',N'ibealton9@cnet.com',N'(765) 3308162',N'MDS000CS606946',12);
INSERT INTO Customer (SSN,Fname,Lname,Gender,Eamil,Phone,Registration_Number,Claim_ID) VALUES
	 (N'522-55-1072',N'Elonore',N'Yesson',N'Female',N'eyessona@google.ca',N'(864) 2070883',N'MDS00044606949',21),
	 (N'329-42-9301',N'Garry',N'Galley',N'Male',N'ggalleyb@mtv.com',N'(914) 1321447',N'MDS000GB555700',22),
	 (N'761-89-5915',N'Tyrus',N'Bonevant',N'Male',N'tbonevantc@eventbrite.com',N'(915) 8295677',N'MDS000BA099688',14),
	 (N'683-66-1191',N'Waylan',N'Chessell',N'Male',N'wchesselld@bloomberg.com',N'(617) 4836190',N'MDS000F5137462',15),
	 (N'169-30-8380',N'Tanner',N'Gwilt',N'Male',N'tgwilte@google.com.hk',N'(303) 2450704',N'MDS000DM568610',16),
	 (N'756-57-3352',N'Cirilo',N'Loache',N'Male',N'cloachef@ucoz.ru',N'(850) 7016449',N'MDS000EW720296',23),
	 (N'768-97-0357',N'Melessa',N'Ivett',N'Non-binary',N'mivettg@meetup.com',N'(202) 2943004',N'MDS000EN925570',19),
	 (N'879-10-2693',N'Hyacinthia',N'Heinke',N'Female',N'hheinkeh@is.gd',N'(702) 4810268',N'MDS000EE260578',18),
	 (N'291-33-7723',N'Cob',N'Robatham',N'Male',N'crobathami@census.gov',N'(619) 2803968',N'MDS0007A119240',20),
	 (N'557-07-0529',N'Stanwood',N'Tumilson',N'Male',N'stumilsonj@rediff.com',N'(419) 5653056',N'MDS000DL183076',24);
INSERT INTO Customer (SSN,Fname,Lname,Gender,Eamil,Phone,Registration_Number,Claim_ID) VALUES
	 (N'719-60-5112',N'Ky',N'Mannie',N'Male',N'kmanniek@yellowpages.com',N'(202) 8719498',N'MDS0007K362760',25),
	 (N'418-75-3739',N'Giordano',N'McEvon',N'Male',N'gmcevonl@qq.com',N'(937) 3410043',N'MDS000AN738493',26),
	 (N'460-99-9910',N'Helsa',N'Cuffe',N'Agender',N'hcuffem@nifty.com',N'(313) 4820485',N'MDS000FB434859',27),
	 (N'381-21-5453',N'Franny',N'Gerrels',N'Female',N'fgerrelsn@independent.co.uk',N'(415) 4206034',N'MDS0009C787070',NULL),
	 (N'814-60-9471',N'Prent',N'Succamore',N'Male',N'psuccamoreo@xrea.com',N'(206) 4888630',N'MDS000EP000021',NULL),
	 (N'446-64-1734',N'Hunt',N'Bart',N'Male',N'hbartp@ycombinator.com',N'(954) 4661896',N'MDS000BN524994',NULL),
	 (N'873-69-6844',N'Devondra',N'Hiscoke',N'Female',N'dhiscokeq@intel.com',N'(785) 3562550',N'MDS000D4392632',NULL),
	 (N'385-34-8652',N'Gena',N'Cobello',N'Female',N'gcobellor@printfriendly.com',N'(210) 9839342',N'MDS000EH842482',NULL),
	 (N'334-31-1032',N'Koressa',N'Daen',N'fluid',N'kdaens@theguardian.com',N'(563) 1165909',N'MDS000CK729752',NULL),
	 (N'213-47-4847',N'Any',N'Belch',N'Male',N'abelcht@163.com',N'(727) 3873789',N'MDS000DD808731',NULL);
INSERT INTO Customer (SSN,Fname,Lname,Gender,Eamil,Phone,Registration_Number,Claim_ID) VALUES
	 (N'699-39-9708',N'Darcey',N'Gayle',N'Female',N'dgayleu@indiegogo.com',N'(210) 1808330',N'MDS000DN538186',NULL),
	 (N'390-88-9780',N'Arther',N'Cowope',N'Male',N'acowopev@miibeian.gov.cn',N'(816) 3841605',N'MDS0001K604957',NULL),
	 (N'863-09-9700',N'Beaufort',N'Durdy',N'Male',N'bdurdyw@eepurl.com',N'(773) 1455817',N'MDS000EF896050',NULL),
	 (N'461-31-8153',N'Sean',N'Ausello',N'Male',N'sausellox@cargocollective.com',N'(810) 9010434',N'MDS000DN868121',NULL),
	 (N'784-26-7638',N'Ardelia',N'Dudgeon',N'Female',N'adudgeony@nydailynews.com',N'(937) 4118434',N'MDS000FC740876',NULL),
	 (N'120-41-3559',N'Nelia',N'Crumpe',N'gender',N'ncrumpez@amazon.co.uk',N'(805) 8019342',N'MDS000E0151309',NULL),
	 (N'105-89-9173',N'Sella',N'Fillingham',N'Female',N'sfillingham10@noaa.gov',N'(304) 9406845',N'MDS000BZ290756',NULL),
	 (N'512-72-5318',N'Thatch',N'Reinbach',N'Male',N'treinbach11@g.co',N'(309) 1344575',N'MDS0008N421897',NULL),
	 (N'775-79-4115',N'Lewie',N'Reddihough',N'Male',N'lreddihough12@pcworld.com',N'(219) 2221805',N'MDS000EA758536',NULL),
	 (N'865-49-3935',N'Lief',N'Gogerty',N'Male',N'lgogerty13@pagesperso-orange.fr',N'(212) 4854334',N'MDS0005A391192',NULL);
INSERT INTO Customer (SSN,Fname,Lname,Gender,Eamil,Phone,Registration_Number,Claim_ID) VALUES
	 (N'143-31-6207',N'Theodora',N'Bollom',N'Female',N'tbollom14@booking.com',N'(712) 5046406',N'MDS000AE294008',NULL),
	 (N'837-25-0425',N'Millisent',N'Stopps',N'Non-binary',N'mstopps15@seattletimes.com',N'(210) 3269530',N'MDS000AE720659',NULL),
	 (N'564-25-9458',N'Kerry',N'Vivers',N'queer',N'kvivers16@tripadvisor.com',N'(585) 4468296',N'MDS000AB527556',NULL),
	 (N'707-86-0445',N'Mikol',N'Busain',N'Male',N'mbusain17@ezinearticles.com',N'(214) 9759501',N'MDS000BM866631',NULL),
	 (N'667-80-7417',N'Tammy',N'Rosten',N'fluid',N'trosten18@baidu.com',N'(540) 8206291',N'MDS0009C914095',NULL),
	 (N'436-54-8234',N'Cheryl',N'Fowle',N'Female',N'cfowle19@symantec.com',N'(702) 5145033',N'MDS0009R281879',NULL),
	 (N'690-17-9987',N'Wilow',N'Shimmin',N'Female',N'wshimmin1a@wufoo.com',N'(404) 3814655',N'MDS0006G769981',NULL),
	 (N'671-79-3284',N'Jane',N'McTavish',N'Female',N'jmctavish1b@wix.com',N'(602) 1747154',N'MDS0005D434794',NULL),
	 (N'549-18-1437',N'Florry',N'Crunkhurn',N'Agender',N'fcrunkhurn1c@bbb.org',N'(757) 3715441',N'MDS000BG467300',NULL),
	 (N'199-64-3068',N'Jolynn',N'Dobby',N'Female',N'jdobby1d@sogou.com',N'(202) 7599796',N'MDS000CW331385',NULL);
INSERT INTO Customer (SSN,Fname,Lname,Gender,Eamil,Phone,Registration_Number,Claim_ID) VALUES
	 (N'565-55-8649',N'Skip',N'Thunder',N'Male',N'sthunder1e@delicious.com',N'(773) 7445099',N'MDS000AK662331',NULL),
	 (N'729-57-9679',N'Karita',N'Sigward',N'Female',N'ksigward1f@cpanel.net',N'(203) 2062974',N'MDS000EM897196',NULL),
	 (N'581-58-7369',N'Astrid',N'Charlick',N'Female',N'acharlick1g@about.me',N'(719) 3758153',N'MDS000EG641626',NULL),
	 (N'488-71-2426',N'Rosalinde',N'Goodban',N'Female',N'rgoodban1h@joomla.org',N'(213) 2483382',N'MDS000FM934193',NULL),
	 (N'176-12-9726',N'Griffith',N'Lermouth',N'Male',N'glermouth1i@prweb.com',N'(972) 5743941',N'MDS000F2387834',NULL),
	 (N'887-24-5953',N'Terri',N'Murdie',N'Male',N'tmurdie1j@so-net.ne.jp',N'(605) 2824430',N'MDS000AU889941',NULL),
	 (N'518-56-8997',N'Gordan',N'Mawby',N'Male',N'gmawby1k@timesonline.co.uk',N'(661) 2066684',N'MDS000EF799871',NULL),
	 (N'139-47-1151',N'Jervis',N'Kenwin',N'gender',N'jkenwin1l@columbia.edu',N'(704) 2862876',N'MDS0004N792914',NULL),
	 (N'511-10-8477',N'Lela',N'O''Kinneally',N'Female',N'lokinneally1m@netlog.com',N'(205) 2423102',N'MDS0002U710469',NULL),
	 (N'150-81-6898',N'Alissa',N'Mitford',N'Female',N'amitford1n@hc360.com',N'(206) 7734972',N'MDS000CT365211',NULL);
INSERT INTO Customer (SSN,Fname,Lname,Gender,Eamil,Phone,Registration_Number,Claim_ID) VALUES
	 (N'710-61-7100',N'Merilee',N'Marginson',N'Female',N'mmarginson1o@usatoday.com',N'(612) 5028036',N'MDS0005D285004',NULL),
	 (N'378-65-9110',N'Ezra',N'Astlett',N'Male',N'eastlett1p@bloglines.com',N'(302) 1174534',N'MDS000FU365753',NULL),
	 (N'584-19-1503',N'Sully',N'Saladin',N'Male',N'ssaladin1q@dagondesign.com',N'(562) 2551618',N'MDS000DC648838',NULL),
	 (N'507-02-8146',N'Pier',N'Butterworth',N'Female',N'pbutterworth1r@fda.gov',N'(210) 7885376',N'MDS0003C670399',NULL),
	 (N'761-91-5307',N'Dalenna',N'Aherne',N'Female',N'daherne1s@purevolume.com',N'(601) 8883581',N'MDS000D0180224',NULL),
	 (N'479-45-5204',N'Willis',N'Wickrath',N'Male',N'wwickrath1t@comsenz.com',N'(571) 7969140',N'MDS000FA554702',NULL),
	 (N'340-09-7770',N'Teodorico',N'Levison',N'Male',N'tlevison1u@t-online.de',N'(484) 3876058',N'MDS000CG329305',NULL),
	 (N'322-58-1007',N'Jeremie',N'Gook',N'Male',N'jgook1v@cbc.ca',N'(706) 2056931',N'MDS000FS409852',NULL),
	 (N'306-11-8186',N'Haskell',N'D''Alessandro',N'Male',N'hdalessandro1w@reuters.com',N'(330) 7227979',N'MDS0003G574620',NULL),
	 (N'459-19-3197',N'Gelya',N'Waiting',N'Female',N'gwaiting1x@yolasite.com',N'(561) 7178311',N'MDS000FN906176',NULL);
INSERT INTO Customer (SSN,Fname,Lname,Gender,Eamil,Phone,Registration_Number,Claim_ID) VALUES
	 (N'645-74-7907',N'Maryanna',N'Buxam',N'Female',N'mbuxam1y@netvibes.com',N'(843) 4750589',N'MDS000BS485809',NULL),
	 (N'890-54-8574',N'Joleen',N'Romain',N'Female',N'jromain1z@de.vu',N'(816) 3475907',N'MDS000AT969764',NULL),
	 (N'866-85-3351',N'Fanni',N'Poundford',N'Female',N'fpoundford20@virginia.edu',N'(304) 7153549',N'MDS000FU478082',NULL),
	 (N'486-16-5988',N'Adlai',N'Bedingfield',N'Male',N'abedingfield21@wix.com',N'(407) 1374242',N'MDS0008U711350',NULL),
	 (N'810-64-1684',N'Godwin',N'Crux',N'Male',N'gcrux22@youtube.com',N'(513) 7065060',N'MDS000D6405716',NULL),
	 (N'479-77-0389',N'Whitney',N'Cusiter',N'Female',N'wcusiter23@hostgator.com',N'(513) 6409086',N'MDS00061045300',NULL),
	 (N'598-56-2489',N'Frasquito',N'Stocky',N'Male',N'fstocky24@discovery.com',N'(504) 5918921',N'MDS000EM101273',NULL),
	 (N'479-17-9798',N'Derrik',N'Morcom',N'Male',N'dmorcom25@example.com',N'(254) 3509771',N'MDS000CS770397',NULL),
	 (N'317-77-7015',N'Giavani',N'Allkins',N'Male',N'gallkins26@pcworld.com',N'(602) 7158201',N'MDS000E1279112',NULL),
	 (N'583-74-5547',N'Dru',N'Isted',N'Male',N'disted27@ox.ac.uk',N'(202) 8554799',N'MDS000F6217719',NULL);
INSERT INTO Customer (SSN,Fname,Lname,Gender,Eamil,Phone,Registration_Number,Claim_ID) VALUES
	 (N'537-10-9689',N'Barty',N'Basile',N'Male',N'bbasile28@homestead.com',N'(609) 9506349',N'MDS0006N124455',NULL),
	 (N'212-15-4737',N'Loria',N'Portwain',N'Female',N'lportwain29@usda.gov',N'(215) 7352920',N'MDS000DG379646',NULL),
	 (N'201-54-3110',N'Maire',N'Riccardo',N'Female',N'mriccardo2a@github.io',N'(937) 1805887',N'MDS0008L422839',NULL),
	 (N'192-71-7649',N'Olag',N'Kalisch',N'Male',N'okalisch2b@comsenz.com',N'(602) 7937785',N'MDS000BA882622',NULL),
	 (N'118-88-8497',N'Sayers',N'Pherps',N'Male',N'spherps2c@people.com.cn',N'(240) 4758932',N'MDS000BJ271886',NULL),
	 (N'313-15-0222',N'Cherlyn',N'Rawsthorne',N'Female',N'crawsthorne2d@cisco.com',N'(915) 9679077',N'MDS0001A250091',NULL),
	 (N'572-34-6025',N'Guinevere',N'While',N'Female',N'gwhile2e@studiopress.com',N'(505) 7517614',N'MDS000AM692043',NULL),
	 (N'780-64-4612',N'Alexandros',N'Lundy',N'Male',N'alundy2f@imdb.com',N'(989) 8038222',N'MDS000E0159708',NULL),
	 (N'106-17-3769',N'Arlena',N'Hannaford',N'Bigender',N'ahannaford2g@china.com.cn',N'(940) 9587498',N'MDS000DE361337',NULL),
	 (N'252-66-3212',N'Sigismundo',N'Levesque',N'Male',N'slevesque2h@sun.com',N'(682) 4101567',N'MDS0007C716852',NULL);
INSERT INTO Customer (SSN,Fname,Lname,Gender,Eamil,Phone,Registration_Number,Claim_ID) VALUES
	 (N'810-63-7564',N'Lyndsay',N'Ainscough',N'Female',N'lainscough2i@myspace.com',N'(904) 5239013',N'MDS000BE435334',NULL),
	 (N'738-12-5640',N'Randa',N'Tinkler',N'Female',N'rtinkler2j@state.gov',N'(805) 8596315',N'MDS000AT308925',NULL),
	 (N'417-32-9160',N'Ferdinand',N'Drewell',N'Male',N'fdrewell2k@yahoo.co.jp',N'(727) 8256603',N'MDS000BG121771',NULL),
	 (N'802-02-7962',N'Christiano',N'Glynne',N'Male',N'cglynne2l@mashable.com',N'(904) 5761672',N'MDS0008A192462',NULL),
	 (N'605-80-7323',N'Brand',N'Tomaszkiewicz',N'Male',N'btomaszkiewicz2m@twitter.com',N'(704) 5046397',N'MDS0002A556292',NULL),
	 (N'752-73-8690',N'Amelie',N'Billin',N'Female',N'abillin2n@hubpages.com',N'(319) 2841482',N'MDS0009R227273',NULL),
	 (N'204-06-7047',N'Maxie',N'Worsnip',N'Female',N'mworsnip2o@usatoday.com',N'(316) 7692586',N'MDS000FM006729',NULL),
	 (N'591-81-9583',N'Timothy',N'Bampfield',N'Male',N'tbampfield2p@ibm.com',N'(661) 1191153',N'MDS000CF198556',NULL),
	 (N'470-67-7563',N'Effie',N'MacPaike',N'Female',N'emacpaike2q@photobucket.com',N'(302) 1380805',N'MDS000D0954254',NULL),
	 (N'241-47-1573',N'Stinky',N'Barbe',N'Male',N'sbarbe2r@prlog.org',N'(239) 4083405',N'MDS000BM768569',NULL);

INSERT INTO Address (City,State,Zip) VALUES
	 (N'Urbandale',N'IA',N'50322'),
	 (N'Altoona',N'PA',N'16601'),
	 (N'Apex',N'NC',N'27502'),
	 (N'Lawrence',N'MA',N'01841'),
	 (N'Lorton',N'VA',N'22079'),
	 (N'Summerville',N'SC',N'29483'),
	 (N'Delray Beach',N'FL',N'33445'),
	 (N'Melrose',N'MA',N'02176'),
	 (N'Sicklerville',N'NK',N'08081'),
	 (N'Trussville',N'AL',N'35173');
	
INSERT INTO CustomerAddress (ID,Address_ID) VALUES
	 (1,1),
	 (1,2),
	 (2,2),
	 (2,5),
	 (3,6),
	 (3,7),
	 (4,2),
	 (4,9),
	 (5,10),
	 (6,3);
INSERT INTO CustomerAddress (ID,Address_ID) VALUES
	 (6,7),
	 (7,7),
	 (8,4),
	 (9,4),
	 (10,1);

ALTER TABLE Accident WITH NOCHECK ADD CONSTRAINT BehaviorCheck CHECK ([dbo].[CheckPositionOfDriver]([Accident_ID])=(0));

--**             create views              **--
-- top two cusomer that have the highest amount payable for each year, display the fname and lname horizontally
create view topBillCusomer as
SELECT year(tmp.Claim_date)[year],
STRING_AGG( Fname +' '+Lname 
, ', ')
AS [top people]
FROM (SELECT pc.Claim_ID, pc.Claim_Status,pc.Claim_date, sum(cast(b.Amount_payable as int))[sum],
        rank() over (partition by year(pc.Claim_date) order by sum(cast(b.Amount_payable as int)) desc) [rank]
 FROM dbo.Bill b
 JOIN dbo.Policy_Coverage pc
 ON b.Claim_ID = pc.Claim_ID 
 where pc.Claim_Status = 'Claimed'
 group by pc.Claim_ID, pc.Claim_Status,pc.Claim_date) tmp
 inner join dbo.Customer c  
on c.Claim_ID = tmp.Claim_ID
WHERE [rank] <= 2
GROUP BY year(tmp.Claim_date);

select * from dbo.topBillCusomer;

-- top accident each each year that have the highest vehicle involved, display the vehicle's registration number horizontally

create view topAccident as
SELECT year(tmp.[Date])[year],
STRING_AGG( Registration_Number
, ', ')
AS [vehicle involved]
FROM (select a.Location ,a.[Date] ,a.[Time] ,COUNT(Registration_Number)[count] ,
rank() over (partition by year(a.[Date]) order by COUNT(Registration_Number) desc) [rank]
from dbo.Accident a group by a.Location ,a.[Date] ,a.[Time] having count(Registration_Number) > 2) tmp
 inner join Accident a2 
on tmp.Location = a2.Location and tmp.[Date] = a2.[Date] and tmp.[Time] = a2.[Time]
WHERE [rank] <= 1
GROUP BY year(tmp.[Date]);

select * from dbo.topAccident;